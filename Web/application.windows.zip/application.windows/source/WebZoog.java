import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class WebZoog extends PApplet {

NormalZoog zoog1;
SmartZoog zoog2;
StoppingZoog zoog3;
CrazyZoog zoog4;
Bonus bonus1;
Bonus bonus2;

int s = 0, b = 0;
int speed;
int time = 60, seco, t = 61;

public void setup() {
  size(600, 400);
}

public void draw() {
  background(128);
  if (s == 0) {
    Startscreen();
    zoog1 = new NormalZoog(100, 100, 2, 2);
    zoog2 = new SmartZoog(200, 200, 1, 1);
    zoog3 = new StoppingZoog(300, 300, 3, 3);
    zoog4 = new CrazyZoog(400, 200, 2, 2);
    bonus1 = new Bonus(random(width), random(80, height-80));
    bonus2 = new Bonus(random(width)+width*3, random(80, height-80));
    time = 60;
    t = 61;
  }
  else if (s == 1 && time >= 0) {
    int seco = second();
    if (seco != t) {
      t = seco;
      time--;
    }

    zoog1.move();
    zoog2.move();
    zoog3.move();
    zoog4.move();
    bonus1.move();
    bonus2.move();
    if (zoog1.isDead() == false)
      zoog1.display();
    if (zoog2.isDead() == false)
      zoog2.display();
    if (zoog3.isDead() == false)
      zoog3.display();
    if (zoog4.isDead() == false)
      zoog4.display();
    if (bonus1.isDead() == false)
      bonus1.display();
    if (bonus2.isDead() == false)
      bonus2.display();

    fill(255);
    rect(width/2, 15, width, 30);
    fill(0);
    textSize(20);
    text("Zoog Game", 70, 20);
    text(time +"s", 570, 20);
  }
  else if (s == 2) {
    System.exit(0);
  }
  else if (s == 3) {
    HowToUse();
  }
  else if (s == 4) {
    levelselect();
  }

  if (zoog1.isDead() == true && zoog2.isDead() == true && zoog3.isDead() == true && zoog4.isDead() == true) {
    showWinningMessage();
  }
  else if (time < 0) {
    GameOver();
  }
}


public void mouseClicked() {
  if (zoog1.isDead() == false)
    zoog1.hit(mouseX, mouseY);
  if (zoog3.isDead() == false)
    zoog2.hit(mouseX, mouseY);
  if (zoog3.isDead() == false)
    zoog3.hit(mouseX, mouseY);
  if (zoog4.isDead() == false)
    zoog4.hit(mouseX, mouseY);
  if (bonus1.isDead() == false)
    bonus1.hit(mouseX, mouseY);
  if (bonus2.isDead() == false)
    bonus2.hit(mouseX, mouseY);
}


public void showWinningMessage() {
  background(255);
  fill(0);
  textAlign(CENTER);
  text("You won!", 300, 150);
  textSize(15);
  text("select  and  keystroke", 300, 170);
  textSize(20);
  text("R. Return Start screen", 300, 220);
  text("E. Game end", 300, 250);
  if ((keyPressed == true) && (key == 'r'))
    s = 0;
  else if ((keyPressed == true) && (key == 'e'))
    s = 2;
}

public void Startscreen() {
  fill(0);
  textAlign(CENTER);
  text("Zoog Game", 300, 100);
  textSize(15);
  text("select  and  keystroke", 300, 120);
  textSize(20);
  text("1. Game Start", 300, 170);
  text("2. Game end", 300, 200);
  text("3. How To Use", 300, 230);
  if ((keyPressed == true) && (key == '1')) {
    s = 4;
  }
  else if ((keyPressed == true) && (key == '2')) {
    s = 2;
  }
  else if ((keyPressed == true) && (key == '3')) {
    s = 3;
  }
}

public void GameOver() {

  textAlign(CENTER);
  text("GAME OVER", 300, 100);
  textSize(15);
  text("select  and  keystroke", 300, 120);
  textSize(20);
  text("R. Return Start screen", 300, 170);
  text("E. Game end", 300, 200);
  if ((keyPressed == true) && (key == 'r')) {
    s = 0;
  }
  else if ((keyPressed == true) && (key == 'e')) {
    s = 2;
  }
}

public void HowToUse() {
  text("Let's crush Zoog's eyes.", 300, 100);
  text("You can crush by clicking on the eyes.", 300, 130);
  text("You have to work hard because there are zoog to move.", 300, 150);
  text("If you attack when Zoog's eyes are red, life will increase.", 300, 180);
  text("So be careful", 300, 200);
  text("R. Return Start screen", 300, 250);
  text("E. Game end", 300, 280);
  if ((keyPressed == true) && (key == 'r'))
    s = 0;
  else if ((keyPressed == true) && (key == 'e'))
    s = 2;
}

public void levelselect() {
  text("Level select", 300, 100);
  textSize(15);
  text("select  and  keystroke", 300, 120);
  textSize(20);
  text("N. Normal level", 300, 200);
  text("H. Hard level", 300, 250);
  if ((keyPressed == true) && (key == 'n')) {
    speed = 1;
    s = 1;
  }
  else if ((keyPressed == true) && (key == 'h')) {
    speed = 2;
    s = 1;
  }
}

class Bonus {
  float x, y, num;
  int b = 0;
  Bonus (float x0, float y0) {
    x = x0 + width;
    num = y0;
  }

  public void move() {
    x--;
    y = 50.0f*cos(x/30.0f)+num;
    if (y == num)
      num = random(height);
  }

  public void display() {
    fill(255);
    ellipse(x, y, 30, 30);
    fill(0);
    textSize(10);
    text("+10", x, y+5);
  }

  public void hit(int hx, int hy) {
    if (hy <= y+15 && hy >= y-15) {
      if (hx <= x+15 && hx >= x-15) {
        b++;
        time += 10;
      }
    }
  }

  public boolean isDead() {
    if (b > 0) 
      return true;
    else 
      return false;
  }
}

class CrazyZoog extends Zoog {

  CrazyZoog (int x0, int y0, int il, int ir) {
    super(x0, y0, il, ir);
  }

  public void move() {
    x = (x + PApplet.parseInt(random(12)-7)) % width;
    y = (y + PApplet.parseInt(random(12)-5)) % height;
    if (x < 0) {
      x = width;
    }

    if (y < 0) {
      y = height;
    }
  }
}

class NormalZoog extends Zoog {

  NormalZoog (int x0, int y0, int il, int ir) {
    super(x0, y0, il, ir);
  }

  public void move() {
    x = (x + speed) % width;
    y = (y + speed) % height;
  }
}
class SmartZoog extends Zoog {

  SmartZoog (int x0, int y0, int il, int ir) {
    super(x0, y0, il, ir);
  }
  int m, n ;
  public void move() {
    if ( (mouseX-x)*(mouseX-x)+(mouseY-y)*(mouseY-y)<=100*100) { 
      if (0 <= x - mouseX) {
        m = speed + 1;
      }
      else {
        m = - speed - 1;
      }
      if (0 <= y - mouseY) {
        n = speed + 1;
      }
      else {
        n = -speed - 1;
      }
    }
    else {
      if (m < 0) m = -speed;
      else m = speed;

      if (n < 0) n = -speed;
      else n = speed;
    }
    if (x < 0) {
      x = width;
    }

    if (y < 0) {
      y = height;
    }
    x = (x + m) % width;
    y = (y + n) % height;
  }
}

class StoppingZoog extends Zoog {

  StoppingZoog (int x0, int y0, int il, int ir) {
    super(x0, y0, il, ir);
  }

  public void move() {
    //No move
  }
}

abstract class Zoog {
  int x, y, d = 1;
  int isLeftEyeBroken;
  int isRightEyeBroken;
  int leftD = 0, rightD = 0;
  int leftC = time - PApplet.parseInt(random(time-20));
  int rightC = time - PApplet.parseInt(random(time-20));
  int rc = color(0), lc = color(0);

  Zoog (int x0, int y0, int il, int ir) {
    x = x0;
    y = y0;
    isLeftEyeBroken = il;
    isRightEyeBroken = ir;
  }

  public void display() {
    ellipseMode(CENTER);
    rectMode(CENTER);
    stroke(0);
    fill(175);
    rect(x, y, 20, 100);

    fill(255);
    ellipse(x, y-30, 60, 60);


    if (isLeftEyeBroken > 0) {
      if (leftC >= time && time >= leftC-5)
        lc = color(255, 0, 0);
      else
        lc = color(0);
      fill(lc);
      ellipse(x-19, y-30, 16, 32);
    }

    if (isRightEyeBroken > 0) {
      if (rightC >= time && time >= rightC-5 )
        rc = color(255, 0, 0);
      else
        rc = color(0);
      fill(rc);
      ellipse(x+19, y-30, 16, 32);
    }


    stroke(0);
    line(x-10, y+50, x-20, y+60);
    line(x+10, y+50, x+20, y+60);

    if (leftD > 0 && isLeftEyeBroken >= 0) {
      leftD--;
      fill(255, 0, 0);
      if (d <= 0)
        text("-1", x-19, y-30 -(30 - leftD));
      else
        text("+1", x-19, y-30 -(30 - leftD));
    }
    if (rightD > 0 && isRightEyeBroken >= 0) {
      rightD--;
      fill(255, 0, 0);
      if (d <= 0)
        text("-1", x+19, y-30 -(30 - rightD));
      else
        text("+1", x+19, y-30 -(30 - rightD));
    }
  }

  public abstract void move();

  public void hit(int hx, int hy) {
    if (hy <= y-14 && hy >= y-46) {
      if (hx <= x-11 && hx >= x-27) {
        if (lc == color(0)) {
          d = -1;
          isLeftEyeBroken--;
        }
        else {
          d = +1;
          isLeftEyeBroken++;
        }
        leftD = 30;
      }
    }

    if (hy <= y-14 && hy >= y-46) {
      if (hx <= x+27 && hx >= x+11) {
        if (rc == color(0)) {
          d = -1;
          isRightEyeBroken--;
        }
        else {
          d = +1;
          isRightEyeBroken++;
        }
        rightD = 30;
      }
    }
  }

  public boolean isDead() {
    if (isRightEyeBroken <= 0 && isLeftEyeBroken <= 0) {
      return true;
    }
    else {
      return false;
    }
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "WebZoog" });
  }
}
